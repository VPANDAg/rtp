package com.prtp.config;

import org.bukkit.configuration.file.FileConfiguration;

public record PRTPSettings(
        String worldName,
        int radius,
        int countdownSeconds,
        int cooldownSeconds,
        boolean cancelOnMove,
        boolean chunkPreload,
        int teleportHeightOffset,
        int maxRetriesPerBatch,
        boolean soundsEnabled,
        String startSound,
        String successSound,
        boolean actionbarEnabled,
        boolean bossbarEnabled,
        String bossbarColor,
        String bossbarStyle
) {
    public static PRTPSettings from(FileConfiguration config) {
        return new PRTPSettings(
                config.getString("world", "life"),
                Math.max(1, config.getInt("radius", 2000)),
                Math.max(0, config.getInt("countdown-seconds", 5)),
                Math.max(0, config.getInt("cooldown-seconds", 300)),
                config.getBoolean("cancel-on-move", true),
                config.getBoolean("chunk-preload", true),
                Math.max(1, config.getInt("teleport-height-offset", 1)),
                Math.max(1, config.getInt("max-retries-per-batch", 5)),
                config.getBoolean("sounds.enabled", true),
                config.getString("sounds.start", "BLOCK_NOTE_BLOCK_PLING"),
                config.getString("sounds.success", "ENTITY_ENDERMAN_TELEPORT"),
                config.getBoolean("actionbar.enabled", true),
                config.getBoolean("bossbar.enabled", false),
                config.getString("bossbar.color", "GREEN"),
                config.getString("bossbar.style", "SOLID")
        );
    }
}
