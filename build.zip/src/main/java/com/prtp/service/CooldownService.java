package com.prtp.service;

import com.prtp.config.PRTPSettings;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class CooldownService {
    private final Map<UUID, Instant> cooldowns = new ConcurrentHashMap<>();
    private PRTPSettings settings;

    public CooldownService(PRTPSettings settings) {
        this.settings = settings;
    }

    public void updateSettings(PRTPSettings settings) {
        this.settings = settings;
    }

    public boolean isCoolingDown(Player player) {
        return remainingSeconds(player) > 0;
    }

    public long remainingSeconds(Player player) {
        if (player.hasPermission("prtp.cooldown.bypass")) {
            return 0;
        }
        Instant until = cooldowns.get(player.getUniqueId());
        if (until == null) {
            return 0;
        }
        long remaining = Duration.between(Instant.now(), until).toSeconds();
        if (remaining <= 0) {
            cooldowns.remove(player.getUniqueId());
            return 0;
        }
        return remaining;
    }

    public void start(Player player) {
        if (!player.hasPermission("prtp.cooldown.bypass") && settings.cooldownSeconds() > 0) {
            cooldowns.put(player.getUniqueId(), Instant.now().plusSeconds(settings.cooldownSeconds()));
        }
    }
}
