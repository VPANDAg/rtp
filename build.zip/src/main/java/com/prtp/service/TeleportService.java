package com.prtp.service;

import com.prtp.PRTPPlugin;
import com.prtp.config.PRTPSettings;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public final class TeleportService {
    private final PRTPPlugin plugin;
    private final PRTPSettings settings;
    private final MessageService messages;
    private final CooldownService cooldowns;
    private final Map<UUID, PendingTeleport> pending = new ConcurrentHashMap<>();
    private final Method paperChunkAtAsync;
    private final Method paperTeleportAsync;

    public TeleportService(PRTPPlugin plugin, PRTPSettings settings, MessageService messages, CooldownService cooldowns) {
        this.plugin = plugin;
        this.settings = settings;
        this.messages = messages;
        this.cooldowns = cooldowns;
        this.paperChunkAtAsync = method(World.class, "getChunkAtAsync", int.class, int.class, boolean.class);
        this.paperTeleportAsync = method(Player.class, "teleportAsync", Location.class);
    }

    public void start(Player player, boolean ignoreCooldown) {
        if (!plugin.isRtpEnabled()) {
            messages.send(player, "rtp-disabled");
            return;
        }
        if (pending.containsKey(player.getUniqueId())) {
            messages.send(player, "already-teleporting");
            return;
        }
        if (!ignoreCooldown && cooldowns.isCoolingDown(player)) {
            messages.send(player, "cooldown", Map.of("time", Long.toString(cooldowns.remainingSeconds(player))));
            return;
        }

        PendingTeleport teleport = new PendingTeleport(player.getUniqueId(), player.getLocation().getBlock().getLocation());
        pending.put(player.getUniqueId(), teleport);
        createBossBar(player, teleport);
        runCountdown(player, teleport);
    }

    public boolean hasPending(UUID playerId) {
        return pending.containsKey(playerId);
    }

    public void cancel(Player player, boolean notify) {
        PendingTeleport teleport = pending.remove(player.getUniqueId());
        if (teleport == null) {
            return;
        }
        teleport.cancel();
        if (teleport.countdownTaskId() != -1) {
            Bukkit.getScheduler().cancelTask(teleport.countdownTaskId());
        }
        removeBossBar(player, teleport);
        if (notify) {
            messages.send(player, "teleport-cancelled");
        }
    }

    public void cancelAll() {
        for (UUID playerId : pending.keySet()) {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) {
                cancel(player, false);
            }
        }
        pending.clear();
    }

    private void runCountdown(Player player, PendingTeleport teleport) {
        int seconds = settings.countdownSeconds();
        if (seconds <= 0) {
            findAndTeleport(player, teleport);
            return;
        }

        BukkitRunnable task = new BukkitRunnable() {
            private int remaining = seconds;

            @Override
            public void run() {
                if (teleport.cancelled() || !player.isOnline()) {
                    cancel();
                    return;
                }
                if (remaining <= 0) {
                    cancel();
                    findAndTeleport(player, teleport);
                    return;
                }
                String text = messages.message("teleport-start", Map.of("seconds", Integer.toString(remaining)));
                player.sendMessage(text);
                if (settings.actionbarEnabled()) {
                    sendActionBar(player, text);
                }
                updateBossBar(teleport, remaining / (double) seconds, text);
                playSound(player, settings.startSound());
                remaining--;
            }
        };
        task.runTaskTimer(plugin, 0L, 20L);
        teleport.countdownTaskId(task.getTaskId());
    }

    private void findAndTeleport(Player player, PendingTeleport teleport) {
        World world = Bukkit.getWorld(settings.worldName());
        if (world == null) {
            plugin.validateWorld();
            cancel(player, false);
            messages.send(player, "rtp-disabled");
            return;
        }
        locateAsync(world, 0).thenAccept(location -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (teleport.cancelled() || !player.isOnline() || !pending.containsKey(player.getUniqueId())) {
                return;
            }
            pending.remove(player.getUniqueId());
            removeBossBar(player, teleport);
            teleportPlayer(player, location).thenAccept(success -> Bukkit.getScheduler().runTask(plugin, () -> {
                if (success && player.isOnline()) {
                    cooldowns.start(player);
                    messages.send(player, "teleport-success");
                    playSound(player, settings.successSound());
                }
            }));
        }));
    }

    private CompletableFuture<Location> locateAsync(World world, int batchDepth) {
        CompletableFuture<Location> result = new CompletableFuture<>();
        tryBatch(world, result, 0, batchDepth);
        return result;
    }

    private void tryBatch(World world, CompletableFuture<Location> result, int attempt, int batchDepth) {
        if (result.isDone()) {
            return;
        }
        if (attempt >= settings.maxRetriesPerBatch()) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> tryBatch(world, result, 0, batchDepth + 1), 1L);
            return;
        }

        Location spawn = world.getSpawnLocation();
        int radius = settings.radius();
        int x = spawn.getBlockX() + ThreadLocalRandom.current().nextInt(-radius, radius + 1);
        int z = spawn.getBlockZ() + ThreadLocalRandom.current().nextInt(-radius, radius + 1);
        CompletableFuture<Chunk> chunkFuture = loadChunk(world, x >> 4, z >> 4);

        chunkFuture.whenComplete((chunk, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (error == null) {
                Location candidate = candidateAt(world, x, z);
                if (candidate != null) {
                    result.complete(candidate);
                    return;
                }
            }
            tryBatch(world, result, attempt + 1, batchDepth);
        }));
    }

    private Location candidateAt(World world, int x, int z) {
        Block block = world.getHighestBlockAt(x, z);
        Material type = block.getType();
        if (block.getY() <= world.getMinHeight() || type.isAir() || type == Material.WATER || type == Material.LAVA) {
            return null;
        }
        Block above = block.getRelative(0, 1, 0);
        if (above.isLiquid()) {
            return null;
        }
        double y = block.getY() + settings.teleportHeightOffset();
        Location location = new Location(world, x + 0.5, y, z + 0.5);
        location.setYaw(ThreadLocalRandom.current().nextFloat(360.0F));
        return location;
    }

    private CompletableFuture<Chunk> loadChunk(World world, int chunkX, int chunkZ) {
        if (settings.chunkPreload() && paperChunkAtAsync != null) {
            try {
                @SuppressWarnings("unchecked")
                CompletableFuture<Chunk> future = (CompletableFuture<Chunk>) paperChunkAtAsync.invoke(world, chunkX, chunkZ, true);
                return future;
            } catch (IllegalAccessException | InvocationTargetException ignored) {
                // Fall through to the Spigot-compatible path.
            }
        }

        CompletableFuture<Chunk> future = new CompletableFuture<>();
        Bukkit.getScheduler().runTask(plugin, () -> {
            try {
                future.complete(world.getChunkAt(chunkX, chunkZ));
            } catch (Throwable throwable) {
                future.completeExceptionally(throwable);
            }
        });
        return future;
    }

    private CompletableFuture<Boolean> teleportPlayer(Player player, Location location) {
        if (paperTeleportAsync != null) {
            try {
                @SuppressWarnings("unchecked")
                CompletableFuture<Boolean> future = (CompletableFuture<Boolean>) paperTeleportAsync.invoke(player, location);
                return future;
            } catch (IllegalAccessException | InvocationTargetException ignored) {
                // Fall through to the Spigot-compatible path.
            }
        }

        CompletableFuture<Boolean> future = new CompletableFuture<>();
        Bukkit.getScheduler().runTask(plugin, () -> {
            try {
                future.complete(player.teleport(location));
            } catch (Throwable throwable) {
                future.completeExceptionally(throwable);
            }
        });
        return future;
    }

    private void createBossBar(Player player, PendingTeleport teleport) {
        if (!settings.bossbarEnabled()) {
            return;
        }
        BarColor color = enumValue(BarColor.class, settings.bossbarColor(), BarColor.GREEN);
        BarStyle style = enumValue(BarStyle.class, settings.bossbarStyle(), BarStyle.SOLID);
        BossBar bossBar = Bukkit.createBossBar("Teleporting...", color, style);
        bossBar.addPlayer(player);
        teleport.bossBar(bossBar);
    }

    private void updateBossBar(PendingTeleport teleport, double progress, String text) {
        BossBar bossBar = teleport.bossBar();
        if (bossBar == null) {
            return;
        }
        bossBar.setProgress(Math.max(0.0, Math.min(1.0, progress)));
        bossBar.setTitle(text);
    }

    private void removeBossBar(Player player, PendingTeleport teleport) {
        BossBar bossBar = teleport.bossBar();
        if (bossBar != null) {
            bossBar.removePlayer(player);
            bossBar.removeAll();
        }
    }

    private void playSound(Player player, String soundName) {
        if (!settings.soundsEnabled()) {
            return;
        }
        String sound = soundKey(soundName);
        if (sound != null) {
            player.playSound(player.getLocation(), sound, 1.0F, 1.0F);
        }
    }

    private String soundKey(String soundName) {
        if (soundName == null || soundName.isBlank()) {
            return null;
        }
        String normalized = soundName.toLowerCase(Locale.ROOT);
        if (normalized.contains(":") || normalized.contains(".")) {
            return normalized;
        }
        normalized = normalized.replace('_', '.');
        return normalized.replace("note.block", "note_block");
    }

    private void sendActionBar(Player player, String text) {
        try {
            player.spigot().sendMessage(
                    net.md_5.bungee.api.ChatMessageType.ACTION_BAR,
                    new net.md_5.bungee.api.chat.TextComponent(text)
            );
        } catch (Throwable ignored) {
            // Action bars are optional; chat countdown still works everywhere.
        }
    }

    private Method method(Class<?> owner, String name, Class<?>... parameterTypes) {
        try {
            return owner.getMethod(name, parameterTypes);
        } catch (NoSuchMethodException ignored) {
            return null;
        }
    }

    private <T extends Enum<T>> T enumValue(Class<T> type, String name, T fallback) {
        try {
            return Enum.valueOf(type, name.toUpperCase());
        } catch (IllegalArgumentException | NullPointerException ignored) {
            return fallback;
        }
    }
}
