package com.prtp.service;

import org.bukkit.Location;
import org.bukkit.boss.BossBar;

import java.util.UUID;

public final class PendingTeleport {
    private final UUID playerId;
    private final Location startBlock;
    private BossBar bossBar;
    private int countdownTaskId = -1;
    private boolean cancelled;

    public PendingTeleport(UUID playerId, Location startBlock) {
        this.playerId = playerId;
        this.startBlock = startBlock;
    }

    public UUID playerId() {
        return playerId;
    }

    public Location startBlock() {
        return startBlock;
    }

    public BossBar bossBar() {
        return bossBar;
    }

    public void bossBar(BossBar bossBar) {
        this.bossBar = bossBar;
    }

    public int countdownTaskId() {
        return countdownTaskId;
    }

    public void countdownTaskId(int countdownTaskId) {
        this.countdownTaskId = countdownTaskId;
    }

    public boolean cancelled() {
        return cancelled;
    }

    public void cancel() {
        this.cancelled = true;
    }
}
