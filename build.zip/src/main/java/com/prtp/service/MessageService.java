package com.prtp.service;

import com.prtp.PRTPPlugin;
import com.prtp.config.PRTPSettings;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.Map;

public final class MessageService {
    private final PRTPPlugin plugin;
    private final PRTPSettings settings;

    public MessageService(PRTPPlugin plugin, PRTPSettings settings) {
        this.plugin = plugin;
        this.settings = settings;
    }

    public void send(CommandSender sender, String key) {
        sender.sendMessage(message(key));
    }

    public void send(CommandSender sender, String key, Map<String, String> placeholders) {
        sender.sendMessage(message(key, placeholders));
    }

    public String message(String key) {
        return message(key, Map.of());
    }

    public String message(String key, Map<String, String> placeholders) {
        String prefix = plugin.getConfig().getString("messages.prefix", "&6[PRTP] ");
        String raw = prefix + plugin.getConfig().getString("messages." + key, key);
        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            raw = raw.replace("%" + entry.getKey() + "%", entry.getValue());
        }
        return parse(raw);
    }

    public String raw(String text) {
        return parse(text);
    }

    private String parse(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    public PRTPSettings settings() {
        return settings;
    }
}
