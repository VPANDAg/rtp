package com.prtp.command;

import com.prtp.PRTPPlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public final class RTPCommand implements CommandExecutor, TabCompleter {
    private final PRTPPlugin plugin;

    public RTPCommand(PRTPPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("prtp.admin")) {
                plugin.messages().send(sender, "no-permission");
                return true;
            }
            plugin.reloadServices();
            plugin.messages().send(sender, "reload");
            return true;
        }

        if (args.length == 1) {
            if (!sender.hasPermission("prtp.admin")) {
                plugin.messages().send(sender, "no-permission");
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                plugin.messages().send(sender, "player-not-found");
                return true;
            }
            plugin.teleports().start(target, true);
            return true;
        }

        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "only-players");
            return true;
        }
        if (!player.hasPermission("prtp.use")) {
            plugin.messages().send(player, "no-permission");
            return true;
        }
        plugin.teleports().start(player, false);
        return true;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length != 1 || !sender.hasPermission("prtp.admin")) {
            return List.of();
        }
        List<String> suggestions = new ArrayList<>();
        if ("reload".startsWith(args[0].toLowerCase())) {
            suggestions.add("reload");
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getName().toLowerCase().startsWith(args[0].toLowerCase())) {
                suggestions.add(player.getName());
            }
        }
        return suggestions;
    }
}
