package com.prtp.command;

import com.prtp.PRTPPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;

import java.util.Map;

public final class PRTPInfoCommand implements CommandExecutor {
    private final PRTPPlugin plugin;

    public PRTPInfoCommand(PRTPPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("prtp.admin")) {
            plugin.messages().send(sender, "no-permission");
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("info")) {
            plugin.messages().send(sender, "info", Map.of(
                    "version", plugin.getDescription().getVersion(),
                    "world", plugin.settings().worldName(),
                    "radius", Integer.toString(plugin.settings().radius())
            ));
            return true;
        }
        return false;
    }
}
