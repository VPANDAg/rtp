package com.prtp;

import com.prtp.command.PRTPInfoCommand;
import com.prtp.command.RTPCommand;
import com.prtp.config.PRTPSettings;
import com.prtp.listener.MovementListener;
import com.prtp.service.CooldownService;
import com.prtp.service.MessageService;
import com.prtp.service.TeleportService;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.plugin.java.JavaPlugin;

public final class PRTPPlugin extends JavaPlugin {
    private PRTPSettings settings;
    private MessageService messages;
    private CooldownService cooldowns;
    private TeleportService teleports;
    private boolean rtpEnabled;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        reloadServices();

        RTPCommand rtpCommand = new RTPCommand(this);
        getCommand("rtp").setExecutor(rtpCommand);
        getCommand("rtp").setTabCompleter(rtpCommand);
        getCommand("prtp").setExecutor(new PRTPInfoCommand(this));
        getServer().getPluginManager().registerEvents(new MovementListener(this), this);

        if (Bukkit.getPluginManager().isPluginEnabled("Multiverse-Core")) {
            getLogger().info("Multiverse-Core detected. Configured RTP world will be resolved through Bukkit.");
        }
    }

    @Override
    public void onDisable() {
        if (teleports != null) {
            teleports.cancelAll();
        }
    }

    public void reloadServices() {
        reloadConfig();
        settings = PRTPSettings.from(getConfig());
        messages = new MessageService(this, settings);
        cooldowns = cooldowns == null ? new CooldownService(settings) : cooldowns;
        cooldowns.updateSettings(settings);

        if (teleports != null) {
            teleports.cancelAll();
        }
        teleports = new TeleportService(this, settings, messages, cooldowns);
        validateWorld();
    }

    public void validateWorld() {
        World world = Bukkit.getWorld(settings.worldName());
        rtpEnabled = world != null;
        if (!rtpEnabled) {
            getLogger().warning("Configured RTP world '" + settings.worldName() + "' does not exist. RTP is disabled until the world is available.");
        }
    }

    public PRTPSettings settings() {
        return settings;
    }

    public MessageService messages() {
        return messages;
    }

    public CooldownService cooldowns() {
        return cooldowns;
    }

    public TeleportService teleports() {
        return teleports;
    }

    public boolean isRtpEnabled() {
        return rtpEnabled;
    }
}
